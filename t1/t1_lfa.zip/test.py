'''
	Arquivo de teste.

'''
from detAfnd import *

n = determinizeAfnd("test.in")
n.printTable()
n.determinize()
n.printTable()