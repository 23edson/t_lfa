
'''
	Arquivo de teste.

'''

from apnd import *

n = Ap("test2.in",True)
n.execute(500000)